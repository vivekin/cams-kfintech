import os
import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk

IMAGE_FOLDER = "captcha_images"
SUPPORTED_EXTS = (".png")

class CaptchaVerifier:
    def __init__(self, root):
        self.root = root
        self.root.title("Captcha Image Verifier")

        self.files = [
            f for f in os.listdir(IMAGE_FOLDER)
            if f.lower().endswith(SUPPORTED_EXTS)
        ]
        self.files.sort()
        self.index = 0

        # Image display
        self.image_label = tk.Label(root)
        self.image_label.pack(pady=10)

        # Filename entry
        self.entry = tk.Entry(
    root,
    font=("Arial", 28),  # BIG text
    width=20             # wider characters
)
        self.entry.pack(pady=5)

        # Buttons
        btn_frame = tk.Frame(root)
        btn_frame.pack(pady=10)

        tk.Button(btn_frame, text="⬅ Previous", command=self.prev_image).grid(row=0, column=0, padx=5)
        tk.Button(btn_frame, text="💾 Save / Rename", command=self.rename_file).grid(row=0, column=1, padx=5)
        tk.Button(btn_frame, text="Next ➡", command=self.next_image).grid(row=0, column=2, padx=5)

        self.load_image()

    def load_image(self):
        if not self.files:
            messagebox.showinfo("Done", "No images found.")
            self.root.quit()
            return

        filename = self.files[self.index]
        path = os.path.join(IMAGE_FOLDER, filename)

        img = Image.open(path)
        img.thumbnail((400, 200))
        self.tk_img = ImageTk.PhotoImage(img)

        self.image_label.config(image=self.tk_img)
        self.entry.delete(0, tk.END)
        self.entry.insert(0, os.path.splitext(filename)[0])

        self.root.title(f"Captcha Verifier ({self.index + 1}/{len(self.files)})")

    def rename_file(self):
        old_name = self.files[self.index]
        ext = os.path.splitext(old_name)[1]
        base = self.entry.get().strip()
    
        if not base:
            messagebox.showerror("Error", "Filename cannot be empty")
            return
    
        new_name = base + ext
        new_path = os.path.join(IMAGE_FOLDER, new_name)
    
        # Auto-handle duplicates
        counter = 1
        while os.path.exists(new_path):
            new_name = f"{base}_{counter}{ext}"
            new_path = os.path.join(IMAGE_FOLDER, new_name)
            counter += 1
    
        old_path = os.path.join(IMAGE_FOLDER, old_name)
        os.rename(old_path, new_path)
        self.files[self.index] = new_name
    
        self.next_image()


    def next_image(self):
        if self.index < len(self.files) - 1:
            self.index += 1
            self.load_image()

    def prev_image(self):
        if self.index > 0:
            self.index -= 1
            self.load_image()


if __name__ == "__main__":
    root = tk.Tk()
    app = CaptchaVerifier(root)
    root.mainloop()
