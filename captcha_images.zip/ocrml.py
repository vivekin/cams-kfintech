from transformers import VisionEncoderDecoderModel, TrOCRProcessor
import torch
from PIL import Image
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from tqdm import tqdm

class CaptchaSolver:
    def __init__(self, device=None):
        """Initialize model once and reuse it"""
        print("Loading model...")
        self.processor = TrOCRProcessor.from_pretrained("anuashok/ocr-captcha-v2", use_fast=False)
        self.model = VisionEncoderDecoderModel.from_pretrained("anuashok/ocr-captcha-v2")
        
        # Use GPU if available
        if device is None:
            self.device = "cuda" if torch.cuda.is_available() else "cpu"
        else:
            self.device = device
        
        self.model.to(self.device)
        print(f"Model loaded on {self.device}")
    
    def solve_captcha(self, image_path):
        """Solve a single CAPTCHA"""
        try:
            # Load image
            image = Image.open(image_path).convert("RGB")
            
            # Prepare image
            pixel_values = self.processor(image, return_tensors="pt").pixel_values
            pixel_values = pixel_values.to(self.device)
            
            # Generate text
            with torch.no_grad():  # Disable gradient computation for inference
                generated_ids = self.model.generate(pixel_values)
            
            generated_text = self.processor.batch_decode(generated_ids, skip_special_tokens=True)[0]
            
            if generated_text == '' or generated_text == None:
                return None
            return generated_text.replace(" ", "")
        except Exception as e:
            print(f"Error solving {image_path}: {e}")
            return None

def process_batch(solver, image_paths):
    """Process a batch of images"""
    results = []
    for path in image_paths:
        result = solver.solve_captcha(path)
        results.append((path, result))
    return results

def process_captcha_images_fast(directory="./captcha_images/", batch_size=8, num_workers=2):
    """
    Fast processing with batching and optional multi-threading
    
    Args:
        directory: Path to captcha images
        batch_size: Number of images to process in each batch
        num_workers: Number of worker threads (use 1 for single-threaded)
    """
    # Create directory if it doesn't exist
    if not os.path.exists(directory):
        print(f"Directory {directory} does not exist!")
        return
    
    # Get all image files
    image_extensions = ['.png', '.jpg', '.jpeg', '.bmp', '.gif', '.webp']
    image_files = [f for f in os.listdir(directory) 
                   if os.path.splitext(f)[1].lower() in image_extensions]
    
    if not image_files:
        print(f"No image files found in {directory}")
        return
    
    print(f"Found {len(image_files)} images to process...")
    
    # Initialize solver once
    solver = CaptchaSolver()
    
    # Create full paths
    image_paths = [os.path.join(directory, f) for f in image_files]
    
    # Split into batches
    batches = [image_paths[i:i + batch_size] for i in range(0, len(image_paths), batch_size)]
    
    all_results = []
    
    if num_workers > 1:
        # Multi-threaded processing
        print(f"Processing with {num_workers} workers...")
        with ThreadPoolExecutor(max_workers=num_workers) as executor:
            futures = {executor.submit(process_batch, solver, batch): batch for batch in batches}
            
            with tqdm(total=len(image_paths), desc="Processing") as pbar:
                for future in as_completed(futures):
                    results = future.result()
                    all_results.extend(results)
                    pbar.update(len(results))
    else:
        # Single-threaded processing with progress bar
        print("Processing images...")
        with tqdm(total=len(image_paths), desc="Processing") as pbar:
            for batch in batches:
                results = process_batch(solver, batch)
                all_results.extend(results)
                pbar.update(len(results))
    
    # Rename files
    print("\nRenaming files...")
    success_count = 0
    fail_count = 0
    
    for old_path, captcha_text in all_results:
        filename = os.path.basename(old_path)
        
        if captcha_text:
            # Get the file extension
            extension = os.path.splitext(filename)[1]
            
            # Create new filename
            new_filename = f"{captcha_text}{extension}"
            new_path = os.path.join(directory, new_filename)
            
            # Handle duplicate filenames
            counter = 1
            while os.path.exists(new_path):
                new_filename = f"{captcha_text}_{counter}{extension}"
                new_path = os.path.join(directory, new_filename)
                counter += 1
            
            # Rename the file
            try:
                os.rename(old_path, new_path)
                success_count += 1
            except Exception as e:
                print(f"✗ Error renaming {filename}: {e}")
                fail_count += 1
        else:
            fail_count += 1
    
    print(f"\n✓ Successfully processed: {success_count}")
    print(f"✗ Failed: {fail_count}")
    print("Processing complete!")

if __name__ == "__main__":
    # Adjust batch_size and num_workers based on your system
    # For CPU: use num_workers=1 (multi-threading may not help much)
    # For GPU: use num_workers=1 and increase batch_size
    process_captcha_images_fast(
        directory="./captcha_images/",
        batch_size=8,      # Increase if you have GPU memory
        num_workers=1      # Keep at 1 for GPU, or try 2-4 for CPU
    )